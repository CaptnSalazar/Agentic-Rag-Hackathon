# Agentic RAG Knowledge Assistant

## Overview
This project implements a basic Knowledge Assistant with an **Agentic RAG flow**.  
It ingests documents, retrieves relevant knowledge using embeddings + FAISS, and applies an agentic reasoning layer to decide whether to:
- Use RAG for retrieval,
- Perform reasoning,
- Or call an external tool.

## Features
- Knowledge ingestion with embeddings (OpenAI)
- Vector database using FAISS
- Retrieval-Augmented QA
- Agentic decision-making (LangChain ReAct Agent)
- Extensible tool support

## Setup
```bash
pip install -r requirements.txt
```

## Run
```bash
python app.py
```
